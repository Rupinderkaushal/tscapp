import React from 'react'

const About = () => {
  return (
    <div className='home' >This is About Page</div>
  )
}

export default About