import React from 'react'

const Register = () => {
  return (
    <div className='home'> This is  Register Page</div>
  )
}

export default Register