import React from 'react'

const Login = () => {
  return (
    <div className='home'>This is login page</div>
  )
}

export default Login